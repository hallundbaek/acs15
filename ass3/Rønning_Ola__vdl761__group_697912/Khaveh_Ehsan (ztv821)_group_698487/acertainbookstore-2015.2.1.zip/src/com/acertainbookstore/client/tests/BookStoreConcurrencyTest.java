package com.acertainbookstore.client.tests;

import static org.junit.Assert.*;

import java.util.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.acertainbookstore.business.Book;
import com.acertainbookstore.business.BookCopy;
import com.acertainbookstore.business.ConcurrentCertainBookStore;
import com.acertainbookstore.business.ImmutableStockBook;
import com.acertainbookstore.business.StockBook;
import com.acertainbookstore.client.BookStoreHTTPProxy;
import com.acertainbookstore.client.StockManagerHTTPProxy;
import com.acertainbookstore.interfaces.BookStore;
import com.acertainbookstore.interfaces.StockManager;
import com.acertainbookstore.utils.BookStoreConstants;
import com.acertainbookstore.utils.BookStoreException;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;


/**
 * Created by ciprian on 11/26/15.
 */
@RunWith(value = Parameterized.class)
public class BookStoreConcurrencyTest extends Thread {


    private static final int TEST_ISBN = 3044560;
    private static final int NUM_COPIES = 155000;
    private static boolean localTest = true;
    private static StockManager storeManager1;
    private static StockManager storeManager2;
    private static BookStore client1;
    private static BookStore client2;

    private boolean failed = false;
    // parameter tests
    private int repeatsC1;
    private int repeatsC2;
    private int nrThreads;

    public BookStoreConcurrencyTest(int repeats1, int repeats2,int repeats3) {
        this.repeatsC1 = repeats1;
        this.repeatsC2 = repeats2;
        this.nrThreads = repeats3;
    }

    // For TEST1: only the first parameter is used
    //Insert number of iterations,
    // first param is for Thread 1,
    // second for Thread 2 (except Test1 which uses only the first param)
    // third is for nr of threads that we create for multiple thread test
    @Parameterized.Parameters(name = "{index}: run({0}, {1})")
    public static Iterable<Object[]> data1() {
        return Arrays.asList(new Object[][] {
                { 100, 100, 2},
                { 1000, 1000, 15},
                { 300, 1000, 2},
                { 202, 1000, 50}
        });
    }

    @BeforeClass
    public static void setUpBeforeClass() {
        try {
            String localTestProperty = System
                    .getProperty(BookStoreConstants.PROPERTY_KEY_LOCAL_TEST);
            localTest = (localTestProperty != null) ? Boolean
                    .parseBoolean(localTestProperty) : localTest;
            if (localTest) {
                ConcurrentCertainBookStore store = new ConcurrentCertainBookStore();

                storeManager1 = store;
                client1 = store;

                storeManager2 = store;
                client2 = store;
            } else {
                storeManager1 = new StockManagerHTTPProxy(
                        "http://localhost:8081/stock");
                client1 = new BookStoreHTTPProxy("http://localhost:8081");
            }
            storeManager1.removeAllBooks();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Helper method to get the default book used by initializeBooks
     */
    public StockBook getDefaultBook(int copies) {
        return new ImmutableStockBook(TEST_ISBN, "Harry Potter and JUnit",
                "JK Unit", (float) 10, copies, 0, 0, 0, false);
    }


    /**
     * Method to clean up the book store, execute after every test case is run
     */
    @After
    public void cleanupBooks() throws BookStoreException {
        storeManager1.removeAllBooks();
    }


    /**
     * Test1 from requirements
     * * using repeats1 and repeats2 as parameter (nr of calls for c1 and c2 respectively)
     * Both C1 and C2 operate against the same set of books S. C1
     * calls buyBooks, while C2 calls addCopies on S.
     */
    @Test
    public void testConcurrency1() throws BookStoreException {
        // Set of books to buy
//        final int nrRepeats = repeatsC1;
        final int numCopies = repeatsC1;
        final Set<BookCopy> booksToBuy = new HashSet<BookCopy>();
        booksToBuy.add(new BookCopy(TEST_ISBN, 1));

        Set<StockBook> booksToAdd = new HashSet<StockBook>();
        booksToAdd.add(getDefaultBook(numCopies));

        final Set<BookCopy> copiesToAdd = new HashSet<BookCopy>();
        copiesToAdd.add(new BookCopy(TEST_ISBN, 1));

        storeManager2.removeAllBooks();
        storeManager2.addBooks(booksToAdd);

        Thread t1 = new Thread(new Runnable() {
            public void run()
            {
                for(int i =0; i< repeatsC1; i++) {
                    try {
//                        System.out.println("C1: " + storeManager1.getBooks().size());
                        storeManager1.addCopies(copiesToAdd);
//                        System.out.println("C1: " + storeManager1.getBooks().get(0).getNumCopies());
                    } catch (BookStoreException e) {
                        fail("C1: runtime exception");
                        e.printStackTrace();
                    }
                }
            }
        });
        Thread t2 = new Thread(new Runnable() {
            public void run()
            {
                for(int i = 0; i < repeatsC1; i++) {
                    try {
                        client2.buyBooks(booksToBuy);
//                        System.out.println("C2: " + storeManager2.getBooks().get(0).getNumCopies());
                    } catch (BookStoreException e) {
                        fail("C2: Runtime exception");
                        e.printStackTrace();
                    }
                }
            }
        });

        t1.start();
        t2.start();
        try {
            t1.join();
            t2.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
//        System.out.println("Finisain: " + storeManager2.getBooks().get(0).getNumCopies());
        assertTrue(storeManager2.getBooks().get(0).getNumCopies() == numCopies);
    }

    /**
     * Test2 from requirements
     * using repeats1 as parameter (nr of calls for c2)
     * First thread (c1) runs until thread 2 is done (c2)
     * we are testing for consistency,
     * the snapshot returned either has
     * the quantities for all of these books as if they had been just bought or as if they had
     * been just replenished.
     */
    @Test
    public void testConcurrency2() throws BookStoreException {
        // Set of books to buy

        final Set<StockBook> booksInit = new HashSet<StockBook>();
        booksInit.add(new ImmutableStockBook(TEST_ISBN + 1,
                "Harry Potter and Vivek", "JUnit Rowling", (float) 100, 15, 0,
                0, 0, false)); // valid
        booksInit.add(new ImmutableStockBook(TEST_ISBN + 2,
                "Harry Potter and Marcos", "JUnit Rowling", (float) 100, 15, 0,
                0, 0, false)); // invalid copies
        booksInit.add(new ImmutableStockBook(TEST_ISBN + 3,
                "Harry Potter and Concurrency", "JUnit Rowling", (float) 100, 15, 0,
                0, 0, false)); // invalid copies

        final Set<BookCopy> booksToBuy = new HashSet<>();
        booksToBuy.add(new BookCopy(TEST_ISBN + 1, 1));
        booksToBuy.add(new BookCopy(TEST_ISBN + 2, 1));
        booksToBuy.add(new BookCopy(TEST_ISBN + 3, 1));

        // Get a list of ISBNs to retrieved
        final Set<Integer> isbnList = new HashSet<Integer>();
        isbnList.add(TEST_ISBN + 1);
        isbnList.add(TEST_ISBN + 2);
        isbnList.add(TEST_ISBN + 3);

//        storeManager1.removeAllBooks();
        storeManager1.addBooks(booksInit);
        failed = false;

        Thread t1 = new Thread(new Runnable() {
            public void run()
            {
                for(int i = 0; i < repeatsC1; i++) {
                    try {
                        client1.buyBooks(booksToBuy);
                        storeManager1.addCopies(booksToBuy);
                    } catch (BookStoreException e) {
                        ;
                    }
                }
            }});
        Thread t2 = new Thread(new Runnable() {
            public void run()
            {
                int nrCopies;
                while(true) {
                    try {
//                        System.out.println(storeManager2.getBooks().size());
                        //check for atomicity
                        List<StockBook> books = storeManager2.getBooks();

                        //unusual things happen when thread1 interrupts this thread (workaround)
                        if(books.size() < 3) {
                            Thread.currentThread().interrupt();
                            return;
                        }

                        nrCopies = books.get(0).getNumCopies();
                        if (nrCopies != books.get(1).getNumCopies() ||
                                nrCopies != books.get(2).getNumCopies()) {
                            failed = true;
                        }


                    } catch (BookStoreException e) {
                        fail("C2: Runtime exception");
                        e.printStackTrace();
                    }
                }
            }});
        t1.start();
        t2.start();

        while(t1.getState() != State.TERMINATED) {
            ;
        }
        t2.interrupt();

        if(failed) {
            fail();
        }
    }


    /**
     * New test
     * * using repeats1 and repeats2 and nrThreads as parameter (nr of calls for c1, c2
     * and number of threads to spawn respectively)
     * checking if the transaction is atomic for multiple threads
     */
    @Test
    public void testMultipleConcurrency() throws BookStoreException {
        // Set of books to buy

        final Set<StockBook> booksInit = new HashSet<StockBook>();
        booksInit.add(new ImmutableStockBook(TEST_ISBN + 1,
                "Harry Potter and Vivek", "JUnit Rowling", (float) 100, 1, 0,
                0, 0, false)); // valid
        booksInit.add(new ImmutableStockBook(TEST_ISBN + 2,
                "Harry Potter and Marcos", "JUnit Rowling", (float) 100, 1, 0,
                0, 0, false)); // invalid copies
        booksInit.add(new ImmutableStockBook(TEST_ISBN + 3,
                "Harry Potter and Concurrency", "JUnit Rowling", (float) 100, 1, 0,
                0, 0, false)); // invalid copies

        final Set<BookCopy> booksToBuy = new HashSet<>();
        booksToBuy.add(new BookCopy(TEST_ISBN + 1, 1));
        booksToBuy.add(new BookCopy(TEST_ISBN + 2, 1));
        booksToBuy.add(new BookCopy(TEST_ISBN + 3, 1));

        // Get a list of ISBNs to retrieved
        final Set<Integer> isbnList = new HashSet<Integer>();
        isbnList.add(TEST_ISBN + 1);
        isbnList.add(TEST_ISBN + 2);
        isbnList.add(TEST_ISBN + 3);

        storeManager1.removeAllBooks();
        storeManager1.addBooks(booksInit);

        List<Thread> threads = new ArrayList<>();

        failed = false;

        for(int i = 0; i< nrThreads; i++) {
            Thread t1 = new Thread(new Runnable() {
                public void run()
                {
                    for(int i =0; i < repeatsC1; i++) {
                        try {
                            client1.buyBooks(booksToBuy);
                        } catch (BookStoreException e) {
                            //
                        }
                    }
                }});
            Thread t2 = new Thread(new Runnable() {
                public void run()
                {
                    for(int i = 0; i < repeatsC1; i++) {
                        try {
                            storeManager1.addCopies(booksToBuy);
                        } catch (BookStoreException e) {
                        }
                    }
                }});
            Thread t3 = new Thread(new Runnable() {
                public void run()
                {
                    int nrCopies;
                    for(int i = 0; i < repeatsC2; i++) {
                        try {
                            List<StockBook> books = storeManager2.getBooks();
                            //check for atomicity
                            nrCopies = books.get(0).getNumCopies();
                            if(nrCopies != books.get(1).getNumCopies() ||
                                    nrCopies != books.get(2).getNumCopies()){
                                failed = true;
                            }

                        } catch (BookStoreException e) {
//                            e.printStackTrace();
                            ;
                        }
                    }
                }});

            threads.add(t1);
            threads.add(t2);
            threads.add(t3);
        }

        for(Thread thread : threads) {
            thread.start();
        }
        try {
            for(Thread thread : threads) {
                thread.join();
            }
        } catch (InterruptedException e) {
            e.printStackTrace();
            fail();
        }
        if(failed) {
            fail();
        }
    }

    /**
     * New test
     * * using repeats1 and repeats2 and nrThreads as parameter (nr of calls for c1, c2
     * and number of threads to spawn respectively)
     * checking if the transaction is atomic for multiple threads
     */
    @Test
    public void testForDirtyRead() throws BookStoreException {

        final int numCopies = 5, w1 = 15, w2 = 50;
        final Set<StockBook> booksInit = new HashSet<StockBook>();
        booksInit.add(new ImmutableStockBook(TEST_ISBN + 1,
                "Harry Potter and Vivek", "JUnit Rowling", (float) 100, numCopies, 0,
                0, 0, false)); // valid

        // Get a list of ISBNs to retrieved
        final Set<Integer> isbnList = new HashSet<Integer>();
        isbnList.add(TEST_ISBN + 1);

        for (int i = 0 ; i < repeatsC1; i++) {
            failed = false;
            storeManager1.removeAllBooks();
            storeManager1.addBooks(booksInit);

            Thread t1 = new Thread(new Runnable() {
                public void run()
                {
                        try {
                            List<StockBook> books = storeManager1.getBooks();

                            Set<BookCopy> copiesToAdd = new HashSet<BookCopy>();
                            copiesToAdd.add(new BookCopy(books.get(0).getISBN(), w1));

                            storeManager1.addCopies(copiesToAdd);

                        } catch (BookStoreException e) {
                            //
                            fail();
                        }
                }});
            Thread t2 = new Thread(new Runnable() {
                public void run()
                {
                        try {
                            List<StockBook> books = storeManager2.getBooks();

                            Set<BookCopy> copiesToAdd = new HashSet<BookCopy>();

                            copiesToAdd.add(new BookCopy(books.get(0).getISBN(), w2));

                            storeManager2.addCopies(copiesToAdd);

                        } catch (BookStoreException e) {
                            fail();
                        }
                }});

            t1.start();
            t2.start();

            try {
                t1.join();
                t2.join();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            List<StockBook> books = storeManager2.getBooks();

            if(books.get(0).getNumCopies() != numCopies + w1 + w2) {
                failed = true;
                break;
            }
        }

        if(failed) {
            fail();
        }
    }

    /**
     * New test
     *  using repeats1 as parameter (nr of repeats)
     * Testing for deadlocks
     */

    @Test
    public void testForDeadLocks() throws BookStoreException {
        // Set of books to buy
//        final int nrRepeats = repeatsC1;
        final int numCopies = repeatsC1;
        final Set<BookCopy> booksToBuy = new HashSet<BookCopy>();
        booksToBuy.add(new BookCopy(TEST_ISBN, 1));

        final Set<StockBook> booksToAdd = new HashSet<StockBook>();
        booksToAdd.add(getDefaultBook(numCopies));

        final Set<Integer> isbnList = new HashSet<Integer>();
        isbnList.add(TEST_ISBN);

        storeManager2.removeAllBooks();

        for(int i =0; i< repeatsC1; i++) {

            Thread t1 = new Thread(new Runnable() {
                public void run() {
                    try {
                        storeManager1.removeAllBooks();
                        storeManager1.addBooks(booksToAdd);

                    } catch (BookStoreException e) {
                        ;
                    }
                }
            });
            Thread t2 = new Thread(new Runnable() {
                public void run() {
                    for (int i = 0; i < repeatsC2; i++) {
                        try {
                            storeManager2.addBooks(booksToAdd);
                            storeManager2.getBooks();

                        } catch (BookStoreException e) {
                            ;
                        }
                    }
                }
            });

            t1.start();
            t2.start();

            try {
                t1.join();
                t2.join();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        assertTrue(true);
    }


    @AfterClass
    public static void tearDownAfterClass() throws BookStoreException {
        storeManager1.removeAllBooks();
        storeManager2.removeAllBooks();
        if (!localTest) {
            ((BookStoreHTTPProxy) client1).stop();
            ((BookStoreHTTPProxy) client2).stop();
            ((StockManagerHTTPProxy) storeManager1).stop();
            ((StockManagerHTTPProxy) storeManager2).stop();
        }
    }
}
