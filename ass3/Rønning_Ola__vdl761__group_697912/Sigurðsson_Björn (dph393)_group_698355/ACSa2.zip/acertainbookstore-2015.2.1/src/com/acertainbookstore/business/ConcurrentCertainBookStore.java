/**
 *
 */
package com.acertainbookstore.business;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Random;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.locks.ReentrantReadWriteLock;

import com.acertainbookstore.interfaces.BookStore;
import com.acertainbookstore.interfaces.StockManager;
import com.acertainbookstore.utils.BookStoreConstants;
import com.acertainbookstore.utils.BookStoreException;
import com.acertainbookstore.utils.BookStoreUtility;

/**
 * ConcurrentCertainBookStore implements the bookstore and its functionality which is
 * defined in the BookStore
 */
public class ConcurrentCertainBookStore implements BookStore, StockManager {
	private Map<Integer, BookStoreBook> bookMap;
	private Map<Integer, ReentrantReadWriteLock> bookLocks;
	private ReentrantReadWriteLock mapLock;

	public ConcurrentCertainBookStore() {
		// Constructors are not synchronized
		bookMap = new HashMap<>();
		bookLocks = new ConcurrentHashMap<>();
		mapLock = new ReentrantReadWriteLock();
	}
	
	void lockWrite(Set<BookCopy> bookSet) throws BookStoreException {
		if (bookSet == null) {
			throw new BookStoreException(BookStoreConstants.NULL_INPUT);
		}
		mapLock.readLock().lock();
		List<BookCopy> books = new ArrayList<>(bookSet);
		Collections.sort(books);
		for (BookCopy book : books) {
			int ISBN = book.getISBN();
			int numCopies = book.getNumCopies();
			if (BookStoreUtility.isInvalidISBN(ISBN))
				throw new BookStoreException(BookStoreConstants.ISBN + ISBN
						+ BookStoreConstants.INVALID);
			if (BookStoreUtility.isInvalidNoCopies(numCopies))
				throw new BookStoreException(BookStoreConstants.NUM_COPIES
						+ numCopies + BookStoreConstants.INVALID);
			if (!bookMap.containsKey(ISBN))
				throw new BookStoreException(BookStoreConstants.ISBN + ISBN
						+ BookStoreConstants.NOT_AVAILABLE);
			bookLocks.get(ISBN).writeLock().lock();
		}
	}
	
	void unlockWrite(Set<BookCopy> bookSet) {
		if (bookSet == null) return;
		List<BookCopy> books = new ArrayList<>(bookSet);
		Collections.sort(books);
		for (BookCopy book : books) {
			ReentrantReadWriteLock lock = bookLocks.get(book.getISBN());
			if (lock != null && lock.getWriteHoldCount() > 0) {
				lock.writeLock().unlock();
			}
		}
		mapLock.readLock().unlock();
	}
	
	void lockWriteBookEditorPick(Set<BookEditorPick> bookSet) throws BookStoreException {
		if (bookSet == null) {
			throw new BookStoreException(BookStoreConstants.NULL_INPUT);
		}
		mapLock.readLock().lock();
		List<BookEditorPick> books = new ArrayList<>(bookSet);
		Collections.sort(books);
		for (BookEditorPick editorPickArg : books) {
			int ISBN = editorPickArg.getISBN();
			if (BookStoreUtility.isInvalidISBN(ISBN))
				throw new BookStoreException(BookStoreConstants.ISBN + ISBN
						+ BookStoreConstants.INVALID);
			if (!bookMap.containsKey(ISBN))
				throw new BookStoreException(BookStoreConstants.ISBN + ISBN
						+ BookStoreConstants.NOT_AVAILABLE);
			bookLocks.get(ISBN).writeLock().lock();
		}
	}
	
	void unlockWriteBookEditorPick(Set<BookEditorPick> bookSet) {
		if (bookSet == null) return;
		List<BookEditorPick> books = new ArrayList<>(bookSet);
		Collections.sort(books);
		for (BookEditorPick book : books) {
			ReentrantReadWriteLock lock = bookLocks.get(book.getISBN());
			if (lock != null && lock.getWriteHoldCount() > 0) {
				lock.writeLock().unlock();
			}
		}
		mapLock.readLock().unlock();
	}
	
	void lockRead(Collection<BookStoreBook> bookStoreBooks) {
		mapLock.readLock().lock();
		List<BookStoreBook> books = new ArrayList<>(bookStoreBooks);
		Collections.sort(books);
		for (BookStoreBook book : books) {
			bookLocks.get(book.getISBN()).readLock().lock();
		}
	}
	
	void unlockRead(Collection<BookStoreBook> bookStoreBooks) {
		List<BookStoreBook> books = new ArrayList<>(bookStoreBooks);
		Collections.sort(books);
		for (BookStoreBook book : books) {
			bookLocks.get(book.getISBN()).readLock().unlock();
		}
		mapLock.readLock().unlock();
	}
	
	void lockRead(Set<Integer> isbns) throws BookStoreException {
		mapLock.readLock().lock();
		if (isbns == null) {
			throw new BookStoreException(BookStoreConstants.NULL_INPUT);
		}
		List<Integer> sortedIsbns = new ArrayList<>(isbns);
		Collections.sort(sortedIsbns);
		for (Integer ISBN : sortedIsbns) {
			if (BookStoreUtility.isInvalidISBN(ISBN))
				throw new BookStoreException(BookStoreConstants.ISBN + ISBN
						+ BookStoreConstants.INVALID);
			if (!bookMap.containsKey(ISBN))
				throw new BookStoreException(BookStoreConstants.ISBN + ISBN
						+ BookStoreConstants.NOT_AVAILABLE);
			bookLocks.get(ISBN).readLock().lock();
		}
	}
	
	void unlockRead(Set<Integer> isbns) {
		if (isbns == null) return;
		List<Integer> sortedIsbns = new ArrayList<>(isbns);
		Collections.sort(sortedIsbns);
		for (Integer isbn: sortedIsbns) {
			ReentrantReadWriteLock lock = bookLocks.get(isbn);
			if (lock != null && lock.getReadHoldCount() > 0) {
				lock.readLock().unlock();
			}
		}
		mapLock.readLock().unlock();
	}

	public void addBooks(Set<StockBook> bookSet)
			throws BookStoreException {
		if (bookSet == null) {
			throw new BookStoreException(BookStoreConstants.NULL_INPUT);
		}
		// Check if all are there
		for (StockBook book : bookSet) {
			int ISBN = book.getISBN();
			String bookTitle = book.getTitle();
			String bookAuthor = book.getAuthor();
			int noCopies = book.getNumCopies();
			float bookPrice = book.getPrice();
			if (BookStoreUtility.isInvalidISBN(ISBN)
					|| BookStoreUtility.isEmpty(bookTitle)
					|| BookStoreUtility.isEmpty(bookAuthor)
					|| BookStoreUtility.isInvalidNoCopies(noCopies)
					|| bookPrice < 0.0) {
				throw new BookStoreException(BookStoreConstants.BOOK
						+ book.toString() + BookStoreConstants.INVALID);
			} else if (bookMap.containsKey(ISBN)) {
				throw new BookStoreException(BookStoreConstants.ISBN + ISBN
						+ BookStoreConstants.DUPLICATED);
			}
		}
		mapLock.writeLock().lock();
		for (StockBook book : bookSet) {
			int ISBN = book.getISBN();
			bookLocks.put(ISBN, new ReentrantReadWriteLock());
			bookMap.put(ISBN, new BookStoreBook(book));
		}
		mapLock.writeLock().unlock();
	}

	public void addCopies(Set<BookCopy> bookCopiesSet)
			throws BookStoreException {
		try {
			lockWrite(bookCopiesSet);
			// Update the number of copies
			for (BookCopy bookCopy : bookCopiesSet) {
				int ISBN = bookCopy.getISBN();
				int numCopies = bookCopy.getNumCopies();
				BookStoreBook book = bookMap.get(ISBN);
				book.addCopies(numCopies);
			}
		} finally {
			unlockWrite(bookCopiesSet);
		}
	}

	public List<StockBook> getBooks() {
		List<StockBook> listBooks = new ArrayList<>();
		Collection<BookStoreBook> books = bookMap.values();
		lockRead(books);
		for (BookStoreBook book : books) {
			listBooks.add(book.immutableStockBook());
		}
		unlockRead(books);
		return listBooks;
	}

	public void updateEditorPicks(Set<BookEditorPick> editorPicks)
			throws BookStoreException {
		try {
			lockWriteBookEditorPick(editorPicks);
			for (BookEditorPick editorPickArg : editorPicks) {
				bookMap.get(editorPickArg.getISBN()).setEditorPick(
						editorPickArg.isEditorPick());
			}
		} finally {
			unlockWriteBookEditorPick(editorPicks);
		}
	}

	public void buyBooks(Set<BookCopy> bookCopiesToBuy)
			throws BookStoreException {
		try {
			lockWrite(bookCopiesToBuy);
			Boolean saleMiss = false;
			for (BookCopy bookCopy : bookCopiesToBuy) {
				BookStoreBook book = bookMap.get(bookCopy.getISBN());
				if (!book.areCopiesInStore(bookCopy.getNumCopies())) {
					book.addSaleMiss(); // If we cannot sell the copies of the book
					// its a miss
					saleMiss = true;
				}
			}
			// We throw exception now since we want to see how many books in the
			// order incurred misses which is used by books in demand
			if (saleMiss) {
				throw new BookStoreException(BookStoreConstants.BOOK
						+ BookStoreConstants.NOT_AVAILABLE);
			}
			// Then make purchase
			for (BookCopy bookCopyToBuy : bookCopiesToBuy) {
				BookStoreBook book = bookMap.get(bookCopyToBuy.getISBN());
				book.buyCopies(bookCopyToBuy.getNumCopies());
			}
		} finally {
			unlockWrite(bookCopiesToBuy);
		}
	}

	public List<StockBook> getBooksByISBN(Set<Integer> isbnSet)
			throws BookStoreException {
		List<StockBook> listBooks = new ArrayList<>();
		try {
			lockRead(isbnSet);
			for (Integer ISBN : isbnSet) {
				listBooks.add(bookMap.get(ISBN).immutableStockBook());
			}
		} finally {
			unlockRead(isbnSet);
		}
		return listBooks;
	}

	public List<Book> getBooks(Set<Integer> isbnSet)
			throws BookStoreException {
		List<Book> listBooks = new ArrayList<Book>();
		try {
			lockRead(isbnSet);
			for (Integer ISBN : isbnSet) {
				listBooks.add(bookMap.get(ISBN).immutableBook());
			}
		} finally {
			unlockRead(isbnSet);
		}
		return listBooks;
	}

	public List<Book> getEditorPicks(int numBooks)
			throws BookStoreException {
		if (numBooks < 0) {
			throw new BookStoreException("numBooks = " + numBooks
					+ ", but it must be positive");
		}

		mapLock.readLock().lock();
		lockRead(bookMap.values());

		// Get all books that are editor picks
		List<BookStoreBook> listAllEditorPicks = new ArrayList<BookStoreBook>();
		BookStoreBook book;
		Iterator<Entry<Integer, BookStoreBook>> it = bookMap.entrySet()
				.iterator();
		while (it.hasNext()) {
			Entry<Integer, BookStoreBook> pair = (Entry<Integer, BookStoreBook>) it
					.next();
			book = (BookStoreBook) pair.getValue();
			if (book.isEditorPick()) {
				listAllEditorPicks.add(book);
			}
		}

		// Find numBooks random indices of books that will be picked
		Random rand = new Random();
		Set<Integer> tobePicked = new HashSet<Integer>();
		int rangePicks = listAllEditorPicks.size();
		if (rangePicks <= numBooks) {
			// We need to add all the books
			for (int i = 0; i < listAllEditorPicks.size(); i++) {
				tobePicked.add(i);
			}
		} else {
			// We need to pick randomly the books that need to be returned
			int randNum;
			while (tobePicked.size() < numBooks) {
				randNum = rand.nextInt(rangePicks);
				tobePicked.add(randNum);
			}
		}

		// Get the numBooks random books
		List<Book> listEditorPicks = new ArrayList<Book>();
		for (Integer index : tobePicked) {
			book = listAllEditorPicks.get(index);
			listEditorPicks.add(book.immutableBook());
		}
		mapLock.readLock().unlock();
		unlockRead(bookMap.values());
		return listEditorPicks;
	}

	@Override
	public List<Book> getTopRatedBooks(int numBooks)
			throws BookStoreException {
		throw new BookStoreException("Not implemented");
	}

	@Override
	public List<StockBook> getBooksInDemand()
			throws BookStoreException {
		throw new BookStoreException("Not implemented");
	}

	@Override
	public void rateBooks(Set<BookRating> bookRating)
			throws BookStoreException {
		throw new BookStoreException("Not implemented");
	}

	public void removeAllBooks() throws BookStoreException {
		mapLock.writeLock().lock();
		bookMap.clear();
		mapLock.writeLock().unlock();
	}

	public void removeBooks(Set<Integer> isbnSet)
			throws BookStoreException {
		if (isbnSet == null) {
			throw new BookStoreException(BookStoreConstants.NULL_INPUT);
		}
		mapLock.writeLock().lock();
		for (Integer ISBN : isbnSet) {
			if (BookStoreUtility.isInvalidISBN(ISBN)) {
				mapLock.writeLock().unlock();
				throw new BookStoreException(BookStoreConstants.ISBN + ISBN
						+ BookStoreConstants.INVALID);
			}
			if (!bookMap.containsKey(ISBN)) {
				mapLock.writeLock().unlock();
				throw new BookStoreException(BookStoreConstants.ISBN + ISBN
						+ BookStoreConstants.NOT_AVAILABLE);
			}
		}
		for (int isbn : isbnSet) {
			bookLocks.remove(isbn);
			bookMap.remove(isbn);
		}
		mapLock.writeLock().unlock();
	}
}
