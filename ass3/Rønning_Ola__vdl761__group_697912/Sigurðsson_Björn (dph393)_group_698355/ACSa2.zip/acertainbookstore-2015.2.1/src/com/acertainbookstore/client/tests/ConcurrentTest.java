package com.acertainbookstore.client.tests;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.acertainbookstore.business.BookCopy;
import com.acertainbookstore.business.CertainBookStore;
import com.acertainbookstore.business.ConcurrentCertainBookStore;
import com.acertainbookstore.business.ImmutableStockBook;
import com.acertainbookstore.business.StockBook;
import com.acertainbookstore.client.BookStoreHTTPProxy;
import com.acertainbookstore.client.StockManagerHTTPProxy;
import com.acertainbookstore.interfaces.BookStore;
import com.acertainbookstore.interfaces.StockManager;
import com.acertainbookstore.utils.BookStoreConstants;
import com.acertainbookstore.utils.BookStoreException;

public class ConcurrentTest {
	private static final int TEST_ISBN = 3044560;
	private static final int NUM_COPIES = 5;
	private static boolean localTest = true;
	private static StockManager storeManager;
	private static BookStore client;

	@BeforeClass
	public static void setUpBeforeClass() {
		try {
			String localTestProperty = System
					.getProperty(BookStoreConstants.PROPERTY_KEY_LOCAL_TEST);
			localTest = (localTestProperty != null) ? Boolean
					.parseBoolean(localTestProperty) : localTest;
			if (localTest) {
                ConcurrentCertainBookStore store = new ConcurrentCertainBookStore();
//                CertainBookStore store = new CertainBookStore();
				storeManager = store;
				client = store;
			} else {
				storeManager = new StockManagerHTTPProxy(
						"http://localhost:8081/stock");
				client = new BookStoreHTTPProxy("http://localhost:8081");
			}
			storeManager.removeAllBooks();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Helper method to add some books
	 */
	public void addBooks(int isbn, int copies) throws BookStoreException {
		Set<StockBook> booksToAdd = new HashSet<StockBook>();
		StockBook book = new ImmutableStockBook(isbn, "Test of Thrones",
				"George RR Testin'", (float) 10, copies, 0, 0, 0, false);
		booksToAdd.add(book);
		storeManager.addBooks(booksToAdd);
	}
	
	/**
	 * Helper method to add some trilogies
	 */
	public void addTrilogies(int isbn1, int isbn2, int isbn3, int copies) throws BookStoreException {
		Set<StockBook> booksToAdd = new HashSet<>();
		booksToAdd.add(new ImmutableStockBook(isbn1, "Star Wars: A New Hope",
				"George Lucas", (float) 10, copies, 0, 0, 0, false));
		booksToAdd.add(new ImmutableStockBook(isbn2, "Star Wars: The Empire Strikes Back",
				"George Lucas", (float) 10, copies, 0, 0, 0, false));
		booksToAdd.add(new ImmutableStockBook(isbn3, "Star Wars: Return of the Jedi",
				"George Lucas", (float) 10, copies, 0, 0, 0, false));
		storeManager.addBooks(booksToAdd);
	}

	public void removeBook(int isbn) throws BookStoreException {
		Set<Integer> isbnsToRemove= new HashSet<>();
		isbnsToRemove.add(isbn);
		storeManager.removeBooks(isbnsToRemove);
	}
	
	/**
	 * Helper method to add more copies of a trilogy
	 */
	public void addTrilogyCopies(int isbn1, int isbn2, int isbn3, int copies) throws BookStoreException {
		Set<BookCopy> bookCopiesSet = new HashSet<>();
		bookCopiesSet.add(new BookCopy(isbn1, copies));
		bookCopiesSet.add(new BookCopy(isbn2, copies));
		bookCopiesSet.add(new BookCopy(isbn3, copies));
		storeManager.addCopies(bookCopiesSet);
	}

	/**
	 * Helper method to add more copies of a book
	 */
	public void addCopies(int isbn, int copies) throws BookStoreException {
		Set<BookCopy> bookCopiesSet = new HashSet<>();
		BookCopy book = new BookCopy(isbn, copies);
		bookCopiesSet.add(book);
		storeManager.addCopies(bookCopiesSet);
	}
	
	/**
	 * Helper method to buy some books
	 */
	public void buyBooks(int isbn, int copies) throws BookStoreException {
		Set<BookCopy> booksToBuy = new HashSet<>();
		BookCopy book = new BookCopy(isbn, copies);
		booksToBuy.add(book);
		client.buyBooks(booksToBuy);
	}

	/**
	 * Helper method to buy some trilogies
	 */
	public void buyTrilogies(int isbn1, int isbn2, int isbn3, int copies) throws BookStoreException {
		Set<BookCopy> booksToBuy = new HashSet<>();
		booksToBuy.add(new BookCopy(isbn1, copies));
		booksToBuy.add(new BookCopy(isbn2, copies));
		booksToBuy.add(new BookCopy(isbn3, copies));
		client.buyBooks(booksToBuy);
	}

	/**
	 * Helper method to get the default book used by initializeBooks
	 */
	public StockBook getDefaultBook() {
		return new ImmutableStockBook(TEST_ISBN, "Harry Potter and JUnit",
				"JK Unit", (float) 10, NUM_COPIES, 0, 0, 0, false);
	}

	/**
	 * Method to add a book, executed before every test case is run
	 */
	@Before
	public void initializeBooks() throws BookStoreException {
		Set<StockBook> booksToAdd = new HashSet<StockBook>();
		booksToAdd.add(getDefaultBook());
		storeManager.addBooks(booksToAdd);
	}

	/**
	 * Method to clean up the book store, execute after every test case is run
	 */
	@After
	public void cleanupBooks() throws BookStoreException {
		storeManager.removeAllBooks();
	}
	
	@Test
	public void testConcurrentBuyAddBooks() throws BookStoreException {
		int testCopies = 1000000;
		addBooks(TEST_ISBN+10, testCopies);
        ExecutorService executor = Executors.newFixedThreadPool(10);
		Future<Void> clientThread = executor.submit(
				customer(TEST_ISBN+10, 1, testCopies));
		Future<Void> managerThread = executor.submit(
				copyAdder(TEST_ISBN+10, 1, testCopies));
		try {
			clientThread.get();
			managerThread.get();
		} catch (ExecutionException e) {
			throw (BookStoreException) e.getCause();
		} catch (InterruptedException e) {}
		Set<Integer> isbns = new HashSet<>();
		isbns.add(TEST_ISBN+10);
		List<StockBook> books = storeManager.getBooksByISBN(isbns);
		int numCopies = books.get(0).getNumCopies();
		assertTrue(numCopies == testCopies);
	}
	
	@Test
	public void testConcurrentBuyAddTrilogies() throws BookStoreException {
		int testCopies = 1000000;
		addTrilogies(TEST_ISBN+1, TEST_ISBN+2, TEST_ISBN+3, testCopies);
        ExecutorService executor = Executors.newFixedThreadPool(10);
		Future<Void> managerThread = executor.submit(new Callable<Void>() {
			@Override
			public Void call() throws BookStoreException {
				for (int i=0; i<testCopies; i++) {
					addTrilogyCopies(TEST_ISBN+1, TEST_ISBN+2, TEST_ISBN+3, 1);
					Set<Integer> isbns = new HashSet<>();
					for (int j=1; j<4; j++)
						isbns.add(TEST_ISBN+j);
					List<StockBook> books = storeManager.getBooksByISBN(isbns);
					if (!(books.get(0).getNumCopies()
							== books.get(1).getNumCopies()
							&& books.get(1).getNumCopies()
							== books.get(2).getNumCopies())) {
						throw new BookStoreException("Database is inconsistent.");
					}
				}
				return null;
			}
		});
		Future<Void> clientThread = executor.submit(
				customer(TEST_ISBN+1, TEST_ISBN+2, TEST_ISBN+3, 1, testCopies));
		try {
			clientThread.get();
			managerThread.get();
		} catch (ExecutionException e) {
			throw (BookStoreException) e.getCause();
		} catch (InterruptedException e) {}
		Set<Integer> isbns = new HashSet<>();
		for (int i=1; i<4; i++)
			isbns.add(TEST_ISBN+i);
		List<StockBook> books = storeManager.getBooksByISBN(isbns);
		for (StockBook book : books) {
			assertTrue(book.getNumCopies() == testCopies);
		}
	}
	
	Callable<Void> adder(int isbn, int copies) {
		return new Callable<Void>() {
			@Override
			public Void call() {
				while (!Thread.interrupted()) {
					try {
						addBooks(isbn, copies);
					} catch (BookStoreException e) { }
				}
				return null;
			}
		};
	}
	
	Callable<Void> remover(int isbn) {
		return new Callable<Void>() {
			@Override
			public Void call() {
				while (!Thread.interrupted()) {
					try {
						removeBook(isbn);
					} catch (BookStoreException e) { }
				}
				return null;
			}
		};
	}
	
	@Test
	public void testAddBuyRemoveTrilogies() throws BookStoreException {
		int testCopies = 1000;
        ExecutorService executor = Executors.newFixedThreadPool(10);
        List<Future<Void>> managers = new ArrayList<>();
        for (int i=1; i<4; i++)
        	managers.add(executor.submit(adder(TEST_ISBN+i, NUM_COPIES)));
        for (int i=1; i<4; i++)
        	managers.add(executor.submit(remover(TEST_ISBN+i)));
		Future<Integer> buyerClient = executor.submit(new Callable<Integer>() {
			@Override
			public Integer call() {
				int purchases = 0;
				while (purchases < testCopies) {
					try {
						buyTrilogies(TEST_ISBN+1, TEST_ISBN+2, TEST_ISBN+3, 1);
						purchases++;
					} catch (BookStoreException e) { }
				}
				return purchases;
			}
		});
		int purchases = 0;
		try {
			purchases = buyerClient.get();
			for (Future<Void> manager : managers) 
				manager.cancel(true);
		} catch (ExecutionException e) {
			throw (BookStoreException) e.getCause();
		} catch (InterruptedException e) {}
		assertTrue(purchases == testCopies);
	}
	
	Callable<Void> copyAdder(int isbn, int copies, int iterations) {
		return new Callable<Void>() {
			@Override
			public Void call() throws BookStoreException {
				for (int i=0; i < iterations; i++)
					addCopies(isbn, copies);
				return null;
			}
		};
	}

	Callable<Void> copyAdder(int isbn1, int isbn2, int isbn3, int copies, int iterations) {
		return new Callable<Void>() {
			@Override
			public Void call() throws BookStoreException {
				for (int i=0; i < iterations; i++)
					addTrilogyCopies(isbn1, isbn2, isbn3, copies);
				return null;
			}
		};
	}
	
	Callable<Void> customer(int isbn1, int isbn2, int isbn3, int copies, int iterations) {
		return new Callable<Void>() {
			@Override
			public Void call() throws BookStoreException {
				for (int i=0; i<iterations; i++)
					buyTrilogies(isbn1, isbn2, isbn3, copies);
				return null;
			}
		};
	}
	
	Callable<Void> customer(int isbn, int copies, int iterations) {
		return new Callable<Void>() {
			@Override
			public Void call() throws BookStoreException {
				for (int i=0; i<iterations; i++)
					buyBooks(isbn, copies);
				return null;
			}
		};
	}
	
	@Test
	public void testMultipleAddersOneClient() throws BookStoreException {
		int testCopies = 1000;
		addTrilogies(TEST_ISBN+1, TEST_ISBN+2, TEST_ISBN+3, testCopies);
        ExecutorService executor = Executors.newFixedThreadPool(10);
        List<Future<Void>> managers = new ArrayList<>();
        for (int i=1; i<4; i++)
        	managers.add(executor.submit(copyAdder(TEST_ISBN+i, 1, testCopies)));
		Future<Void> customer = executor.submit(customer(
				TEST_ISBN+1, TEST_ISBN+2, TEST_ISBN+3, 1, testCopies));
		try {
			for (Future<Void> manager : managers)
				manager.get();
			customer.get();
		} catch (ExecutionException e) {
			throw (BookStoreException) e.getCause();
		} catch (InterruptedException e) {}
		Set<Integer> isbns = new HashSet<>();
		for (int i=1; i<4; i++)
			isbns.add(TEST_ISBN+i);
		List<StockBook> books = storeManager.getBooksByISBN(isbns);
		for (StockBook book : books) {
			assertTrue(book.getNumCopies() == testCopies);
		}
	}
	
	@Test
	public void testOneAdderMultipleClients() throws BookStoreException {
		int testCopies = 1000;
		addTrilogies(TEST_ISBN+1, TEST_ISBN+2, TEST_ISBN+3, testCopies);
        ExecutorService executor = Executors.newFixedThreadPool(10);
        Future<Void> manager = executor.submit(copyAdder(TEST_ISBN+1, TEST_ISBN+2, TEST_ISBN+3, 1, testCopies));
        List<Future<Void>> customers = new ArrayList<>();
        for (int i=1; i<4; i++)
        	customers.add(executor.submit(customer(TEST_ISBN+i, 1, testCopies)));
		try {
			for (Future<Void> customer : customers)
				customer.get();
			manager.get();
		} catch (ExecutionException e) {
			throw (BookStoreException) e.getCause();
		} catch (InterruptedException e) {}
		Set<Integer> isbns = new HashSet<>();
		for (int i=1; i<4; i++)
			isbns.add(TEST_ISBN+i);
		List<StockBook> books = storeManager.getBooksByISBN(isbns);
		for (StockBook book : books) {
			assertTrue(book.getNumCopies() == testCopies);
		}
	}
	
	@Test
	public void testNonconcurrentMultipleBuysAndAdds() throws BookStoreException {
		int testCopies = 10000000;
		int iters = 6;
		for (int i=1; i<iters; i++) {
			addBooks(TEST_ISBN+i, testCopies);
		}
		for (int j=1; j<iters; j++) {
			for (int i=0; i<testCopies; i++)
				addCopies(TEST_ISBN+j, 1);
			for (int i=0; i<testCopies; i++)
				buyBooks(TEST_ISBN+j, 1);
		}
		Set<Integer> isbns = new HashSet<>();
		isbns.add(TEST_ISBN+1);
		List<StockBook> books = storeManager.getBooksByISBN(isbns);
		assertTrue(books.get(0).getNumCopies() == testCopies);
	}
	
	@Test
	public void testConcurrentMultibleBuysAndAdds() throws BookStoreException {
		int testCopies = 10000000;
		int iters = 6;
		for (int i=1; i<iters; i++) {
			addBooks(TEST_ISBN+i, testCopies);
		}
        ExecutorService executor = Executors.newFixedThreadPool(20);
        List<Future<Void>> people = new ArrayList<>();
        for (int i=1; i<iters; i++) {
        	people.add(executor.submit(copyAdder(TEST_ISBN+i, 1, testCopies)));
        	people.add(executor.submit(customer(TEST_ISBN+i, 1, testCopies)));
        }
		try {
			for (Future<Void> p : people)
				p.get();
		} catch (ExecutionException e) {
			throw (BookStoreException) e.getCause();
		} catch (InterruptedException e) {}
		Set<Integer> isbns = new HashSet<>();
		isbns.add(TEST_ISBN+1);
		List<StockBook> books = storeManager.getBooksByISBN(isbns);
		assertTrue(books.get(0).getNumCopies() == testCopies);
	}
	
	@AfterClass
	public static void tearDownAfterClass() throws BookStoreException {
		storeManager.removeAllBooks();
		if (!localTest) {
			((BookStoreHTTPProxy) client).stop();
			((StockManagerHTTPProxy) storeManager).stop();
		}
	}
}